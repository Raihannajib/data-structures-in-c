#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main() {

    int j=0;  // text file's iterator
    int k=0;  // black pixels
    int i=0;  // white pixels
    int f =0;

    char text[256]="" ;  //text input
    char cod[20]=""; //text output

    char p[4];

    FILE* file ,*file3;
    file = fopen("file.txt","r");
    file3 = fopen("file3.txt","w");
    while ((fscanf(file,"%c",text+f)) != EOF) {
            f++;
        }

     printf(" length of text %d",strlen(text));


    printf("\n");
    while(j<strlen(text)-1) {

        while(j<strlen(text) && *(text+j)=='W'){
            i++;
            j++;
        }
        sprintf(p,"%d%c",i,'W');
        strcat(cod,p);
        i=0;

        if(j>=strlen(text)-1)break;

        while(j<strlen(text) && *(text+j)=='B'){
            k++;
            j++;
        }
        sprintf(p,"%d%c",k,'B');
        strcat(cod,p);
        k=0;

    }
    printf(" length of compressed text %d\n ",strlen(cod));
    printf("%s\n",cod);
   // for (int l = 0; l <strlen(cod) ; ++l) {
     //   putc(cod[l],file2);
    //}
    fputs(cod,file3);
    return 0;

}