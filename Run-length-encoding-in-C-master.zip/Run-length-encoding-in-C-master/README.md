# Run-length-encoding-in-C
Run-length encoding using C
